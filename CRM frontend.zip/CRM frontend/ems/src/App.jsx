import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import NavBar from './layout/NavBar'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Home from './pages/Home'
import AddUser from './users/AddUser'
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import EditUser from './users/EditUser'
import ViewUser from './users/ViewUser'
function App() {
  const [count, setCount] = useState(0)

  return (
    <>

    <Router>
      <NavBar/>
      <Routes>
        <Route exact path="/" element={<Home/>}/>
        <Route exact path="adduser" element={<AddUser/>} />
        <Route exact path="/edituser/:id?" element={<EditUser/>}/>
        <Route exact path="/viewuser/:id?" element={<ViewUser/>}/> 
      </Routes>
    </Router>


      
    </>
  )
}

export default App
