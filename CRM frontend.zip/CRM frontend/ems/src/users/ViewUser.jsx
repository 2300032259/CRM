import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

const ViewUser = () => {
    // Fix: useParams is a hook, it needs to be called as a function
    const { id } = useParams()

    // State for user details
    const [user, setUser] = useState({
        id: "",
        name: "",
        username: "",
        email: ""
    })

    useEffect(() => {
        loadUsers()
    }, []) // Empty dependency array means this runs once on mount

    // Function to load user details
    const loadUsers = async () => {
        try {
            const result = await axios.get(`http://localhost:8085/users/${id}`)
            setUser(result.data)
        } catch (error) {
            console.error("Error loading user:", error)
            // You might want to handle the error state here
        }
    }

    return (
        <div className='container'>
            <div className='row'>
                <div className='col-md-6 offset-md-3 border rounded p-4 mt-2 shadow'>
                    <h6 className='text-center m-1'>View User Information</h6>
                    <div className='card'>
                        <div className='card-header'>
                            Details of User id: {user.id}
                            <ul className='list-group list-group-flush'>
                                <li className='list-group-item'>
                                    <b>Name:</b> {user.name}
                                </li>
                                <li className='list-group-item'>
                                    <b>UserName:</b> {user.username}
                                </li>
                                <li className='list-group-item'>
                                    <b>Email:</b> {user.email}
                                </li>
                            </ul>
                        </div>
                    </div>
                    <Link className='btn btn-primary my-2' to={"/"}>Back to Home</Link>
                </div>
            </div>
        </div>
    )
}

export default ViewUser