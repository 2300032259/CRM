import React, { useState,useEffect } from 'react'
import axios from 'axios'
import { Link, useParams } from 'react-router-dom'
const Home = () => {


const {id}=useParams()

const[users,setUsers]=useState([])
useEffect(()=>{

  loadUsers();
},[])

const loadUsers=async()=>{
  const result=await axios.get("http://localhost:8085/users")
  setUsers(result.data)
}

const deleteUser= async (id)=>{
  await axios.delete(`http://localhost:8085/users/${id}`)
  loadUsers();
}



  return (
    <div className='container'>
        <div className='py-4'>
        <table className="table border shadow">
  <thead>
    <tr>
      <th scope="col">Sno</th>
      <th scope="col">Name</th>
      <th scope="col">Review</th>
      <th scope="col">Email</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    {
      users.map((user,index)=>(
        <tr>
        <th scope="row" key={index}>{index+1}</th>
        <td>{user.name}</td>
        <td>{user.review}</td>
        <td>{user.email}</td>

        <td><Link className='btn btn-primary mx-2' to={`/viewuser/${user.id}`}>View </Link></td>
        <Link className='btn btn-warning mx-2' to={`/edituser/${user.id}`}>Edit </Link>
        <td><button className='btn btn-danger mx-2'
        onClick={()=>deleteUser(user.id)}
        >Delete </button></td>
      </tr>
      ))
    }
    
    
  </tbody>
</table>

        </div>

    </div>
  )
}

export default Home